# Evidence

Store only sanitised project evidence in this directory.

Suggested future files:

```text
01-wazuh-containers-running.png
02-windows-agent-active.png
03-sysmon-event-id-1.png
04-sysmon-event-id-3.png
05-threat-hunting-alert.png
```

Before committing any screenshot or export, remove:

- Passwords, keys and hashes used for authentication
- Email addresses and Microsoft account identifiers
- Windows SIDs
- Public IP addresses
- Browser bookmarks, tabs and unrelated personal content
- Private certificate material
- Full raw logs that may reveal sensitive activity

Each item should have a short explanation in the relevant documentation page rather than being included without context.

