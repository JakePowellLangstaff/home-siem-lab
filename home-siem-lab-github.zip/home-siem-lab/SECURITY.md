# Security and disclosure guidance

This repository is intended to be public. It must contain documentation and sanitised example configuration only.

## Never commit

- Passwords, password hashes, API keys or enrollment keys
- Wazuh `client.keys` or private certificates
- Tailscale authentication material
- SSH private keys
- Router credentials or public IP addresses
- Personally identifying account names, email addresses or Windows SIDs
- Raw logs that include sensitive user, process or network information
- Docker environment files containing secrets

## Repository safeguards

- All credentials used by Wazuh were changed from deployment defaults.
- Example configuration files contain no secrets.
- Private RFC 1918 addresses may appear in explanations, but public addresses should be removed.
- Screenshots must be reviewed and redacted before being added to `evidence/`.
- Production or personally sensitive data must never be used for testing.

## Operational caveats

- No router port forwarding is required for SSH or the Wazuh dashboard.
- Tailscale provides the remote-access overlay and should use device approval, MFA on the identity provider and appropriately scoped access controls.
- The dashboard's locally generated TLS certificate protects transport but is not trusted automatically by browsers. A trusted internal certificate is planned.
- RAID 0 is not a backup. Off-host copies are required before the lab is treated as durable.

